package SOLIDinscriptions.Interfaces;

import SOLIDinscriptions.Student;

public interface enrollmentSubject {

	
	public void setName(String name);
	public String getName();
	public int getSemester();
	public boolean isValidated (Student student);

}
