package SOLIDinscriptions.Interfaces;
import java.util.*;

import SOLIDinscriptions.Subject;

public interface enrollmentStudent {

	public void setName(String name);

	public void setSemester(int semester);

	public String getName();

	public int getSemester();

	public void enroll(Subject subject);

	public LinkedList<Subject> getSubjects();
}