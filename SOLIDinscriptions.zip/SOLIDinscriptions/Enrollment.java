package SOLIDinscriptions;

import java.util.*;

public class Enrollment {

	private Student student = new Student();
	private ArrayList<Subject> subjects = new ArrayList<Subject>();

	public Enrollment() {
		this.getSubjects();

	}

	public void start() {
			this.getStudent();
			this.startEnrollment(this.student, this.subjects);
		}

	private void getSubjects() {
		this.subjects.add(new Subject("Maths", 4));
		this.subjects.add(new Subject("OOPs", 5));
		this.subjects.add(new Subject("SoftwareDesigns", 6));

	}

	private void getStudent() {
		System.out.println("-----SCHEDULE-TEC-----");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("Name:");
		String name = scanner.nextLine();
		System.out.println("Semester:");
		int semester = Integer.parseInt(scanner.nextLine());
		student.setName(name);
		student.setSemester(semester);
	}

	private void startEnrollment(Student student, ArrayList<Subject> subjects) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		String answer;

		System.out.println("Which subject you like to enroll?");
		for (Subject s : subjects) {
			System.out.println("\t" + s.getName());
		}
		System.out.println("Subject:");
		answer = scanner.nextLine();
		this.getAnswer(answer, subjects, student);
	}

	private void getAnswer(String answer, ArrayList<Subject> sc, Student student) {
		if (answer.length() == 0) {
			startEnrollment(student, sc);
			return;
		} else if (new String(answer.toLowerCase()).equals("exit")) {
			this.continueEnrollment(student);
		} else {
			int index = 0;
			for (Subject s : sc) {
				if (new String(s.getName().toLowerCase()).equals(answer.toLowerCase())) {
					if (s.isValidated(student)) {
						System.out.println("Done. Good luck in your '" + s.getName() + "' class");
						student.enroll(s);
						sc.remove(index);
					} else {
						System.out.println(">>>  You can't enroll on this subject until 6th semester");
					}
					break;
				}
				index++;
			}
			startEnrollment(student, sc);
		}
	}

	private void continueEnrollment(Student variable) {
		System.out.println();
		System.out.println("------ Enrollment " + variable.getName() + "-------");
		for (Subject s : variable.getSubjects()) {
			System.out.println(s.getName());
		}
	}
}
